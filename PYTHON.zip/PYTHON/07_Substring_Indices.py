def find_indices(text, sub):
    if sub == "":
        return list(range(len(text) + 1))

    indices = []
    start = 0

    while True:
        index = text.find(sub, start)
        if index == -1:
            break
        indices.append(index)
        start = index + 1

    return indices if indices else -1

text = input("Enter main string: ")
sub = input("Enter substring: ")

print("Indices:", find_indices(text, sub))
