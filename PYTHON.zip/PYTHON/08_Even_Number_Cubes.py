items = input("Enter numbers separated by spaces: ").split()
numbers = []

for item in items:
    try:
        numbers.append(int(item))
    except ValueError:
        pass

cubes_loop = []
for n in numbers:
    if n % 2 == 0:
        cubes_loop.append(n**3)

cubes_comprehension = [
    n**3 for n in numbers if n % 2 == 0
]

print("Using loop:", cubes_loop)
print("Using list comprehension:", cubes_comprehension)