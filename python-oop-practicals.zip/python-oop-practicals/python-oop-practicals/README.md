# Object Oriented Programming Using Python — Practicals

A collection of Python practical programs based on the **Suggested Practical List** in the course document *Object Oriented Programming using Python* (NEP UGCF 2022). A simple calculator practical is also included as an extra.

## Requirements

- Python 3.9 or newer
- No third-party packages required

## How to run

Clone or download this repository, open a terminal in the project folder, and run any practical:

```bash
python practicals/01_quadratic_roots.py
```

Replace the filename with the practical you want to run. On some systems, use `python3` instead of `python`.

## Practical list

| No. | Practical | File |
|---:|---|---|
| 1 | Find the roots of a quadratic equation | [`01_quadratic_roots.py`](practicals/01_quadratic_roots.py) |
| 2 | Check whether `n` is prime; generate primes up to `n`; generate the first `n` primes | [`02_prime_numbers.py`](practicals/02_prime_numbers.py) |
| 3 | Print a `*` pyramid and a reverse pyramid | [`03_star_pyramids.py`](practicals/03_star_pyramids.py) |
| 4 | Classify a character; identify letter case; print a digit's name in words | [`04_character_check.py`](practicals/04_character_check.py) |
| 5 | String character frequency, replacement, remove first occurrence, remove all occurrences | [`05_string_operations.py`](practicals/05_string_operations.py) |
| 6 | Swap the first `n` characters of two strings | [`06_swap_string_prefixes.py`](practicals/06_swap_string_prefixes.py) |
| 7 | Return all indices where the second string occurs in the first, or `-1` | [`07_substring_indices.py`](practicals/07_substring_indices.py) |
| 8 | Cubes of even integers in a mixed-type list, using a loop and list comprehension | [`08_even_number_cubes.py`](practicals/08_even_number_cubes.py) |
| 9 | File character/word/line counts, character frequency, reverse word order, split even/odd lines into `File1`/`File2` | [`09_file_operations.py`](practicals/09_file_operations.py) |
| 10 | Dictionary mapping numbers 1–5 to their cubes | [`10_dictionary_cubes.py`](practicals/10_dictionary_cubes.py) |
| 11 | Tuple halves, even-number tuple, concatenate tuples, maximum and minimum | [`11_tuple_operations.py`](practicals/11_tuple_operations.py) |
| 12 | `Employee` class with object count, validation, salary, destructor, and formatted display | [`12_employee_class.py`](practicals/12_employee_class.py) |
| 13 | `2DPoint` class and distance between two points | [`13_2d_point.py`](practicals/13_2d_point.py) |
| 14 | Inherit the point class as `3Dpoint` and override distance calculation | [`14_3d_point.py`](practicals/14_3d_point.py) |
| 15 | Raise and handle exceptions for names containing digits or special characters | [`15_name_validation.py`](practicals/15_name_validation.py) |
| Extra | Simple calculator for addition, subtraction, multiplication, and division | [`16_simple_calculator.py`](practicals/16_simple_calculator.py) |

## Notes

- The first 15 items follow the uploaded course document's practical list. The calculator is an **extra practical**.
- Practical 9 creates `File1` and `File2` in the current working directory. Enter a valid text-file path when prompted.
- Practical 12 exits with an error if Basic, DA, or HRA is negative, as requested by the syllabus.
- The class in Practical 13 is named `Point2D` because Python identifiers cannot begin with a digit. Practical 14 extends it as `Point3D`.
- These are beginner-friendly sample solutions; follow any additional formatting or submission requirements from your instructor.

## Suggested repository structure

```text
python-oop-practicals/
├── README.md
└── practicals/
    ├── 01_quadratic_roots.py
    ├── ...
    └── 16_simple_calculator.py
```
